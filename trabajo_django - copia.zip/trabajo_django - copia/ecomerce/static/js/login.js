// 1. Obtén el FORMULARIO, no solo el botón
const loginForm = document.getElementById('loginForm');
const errorMessage = document.getElementById('errorMessage');

function displayError(message) {
    errorMessage.textContent = message;
    errorMessage.classList.remove('hidden');
}

function verificacion(e) {
    e.preventDefault(); // Detiene el envío normal del formulario

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Nota: Esta es una verificación ESTÁTICA y SOLO FUNCIONA 
    // si el usuario ingresa exactamente 'angel.guerreo999@gmail.com' y '1032014008' (como string o number).
    const data = [{
        email: "angel.guerreo999@gmail.com",
        password: 1032014008
    }];

    // Asegúrate de que estás comparando tipos correctos (ej. 1032014008 vs "1032014008")
    const user = data.find(user => 
        user.email === email && 
        user.password.toString() === password
    );

    if (user) {
        // 2. Corregido el error de tipeo en la URL
            window.location.replace('/dashboard/') ; 
    } else {
        // Opcional: Mostrar error si las credenciales fallan
        displayError("Credenciales inválidas. Verifica el correo y la contraseña.");
    }
}

// 3. Escucha el evento 'submit' en el FORMULARIO
if (loginForm) {
    loginForm.addEventListener("submit", verificacion);
} else {
    console.error("Error: No se encontró el elemento con ID 'loginForm'.");
}