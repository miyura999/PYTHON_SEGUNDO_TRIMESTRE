//links de las apis
const API_URL_CLIENTES = "http://127.0.0.1:8000/api/clientes/";
const API_URL_PRODUCTOS = "http://127.0.0.1:8000/api/productos/";
const API_URL_VENTAS = "http://127.0.0.1:8000/api/ventas/";
const API_URL_DETALLES = "http://127.00.0.1:8000/api/detalles/";

//traer los id de los formularios
const formCliente = document.getElementById('formCliente');
const formClienteEdit = document.getElementById('formCliente1');
const modalEdit = document.getElementById('modal-cliente1');

const formProducto = document.getElementById('formProducto');
const formProductoEdit = document.getElementById('formProducto1');
const modalEdit1 = document.getElementById('modal-producto2');

const formVenta = document.getElementById('formVenta');
const formVentaEdit = document.getElementById('formVenta1'); 
const modalEditVenta = document.getElementById('modal-venta1'); 

const formDetalleVenta = document.getElementById('formDetalleVenta');
const formDetalleVentaEdit = document.getElementById('formDetalleVenta1');
const modalEditDetalle = document.getElementById('modal-detalle1');

const cerrar = document.getElementById('cerrar');

let currentEditId = null;
let currentEditId1 = null;
let currentEditVentaId = null; 
let currentEditDetalleId = null; 

// ==================== FUNCIONES DE DASHBOARD ====================

async function cargarDashboard() {
  try {
    
    // Obtener total de clientes
    const resClientes = await fetch(API_URL_CLIENTES);
    const dataClientes = await resClientes.json();
    document.getElementById('totalClientes').textContent = dataClientes.length;
    
    // Obtener total de productos
    const resProductos = await fetch(API_URL_PRODUCTOS);
    const dataProductos = await resProductos.json();
    document.getElementById('totalProductos').textContent = dataProductos.length;

    // Obtener total de ventas (Sigue usando la API de ventas para el conteo)
    const resVentas = await fetch(API_URL_VENTAS);
    const dataVentas = await resVentas.json();
    document.getElementById('totalVentas').textContent = dataVentas.length;
    
    // OBTENER INGRESOS TOTALES SUMANDO LOS SUBTOTALES DEL DETALLE VENTA (MODIFICADO)
    const resDetalles = await fetch(API_URL_DETALLES);
    const dataDetalles = await resDetalles.json();

    let ingresoTotal = dataDetalles.reduce((sum, d) => sum + (parseFloat(d.subtotal || 0) || 0), 0);
    document.getElementById('ingresoTotal').textContent = `$${ingresoTotal.toFixed(2)}`;

  } catch (error) {
    console.error("Error al cargar datos del dashboard:", error);
    // Mostrar errores en el dashboard si las llamadas fallan
    document.getElementById('totalClientes').textContent = 'Error';
    document.getElementById('totalProductos').textContent = 'Error';
    document.getElementById('totalVentas').textContent = 'Error';
    document.getElementById('ingresoTotal').textContent = 'Error';
  }
}

// ==================== FUNCIONES DE PRODUCTOS ====================

async function listarProducto() {
  try {
    const res = await fetch(API_URL_PRODUCTOS);
    if (!res.ok) throw new Error("Error al cargar productos");

    const data = await res.json();
    let tabla = document.getElementById("tablaProductos");
    tabla.innerHTML = "";

    data.forEach(c => {
      let tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="p-3">${c.id}</td>
        <td class="p-3">${c.nombre}</td>
        <td class="p-3">${parseFloat(c.precio || 0).toFixed(2)}</td>
        <td class="p-3">${c.stock}</td>
        <td class="p-3">
          <button onclick='mostrarModalEditar1(${JSON.stringify(c)})' class="text-blue-600 hover:underline">Editar</button>
          <button onclick="eliminarProducto(${c.id})" class="text-red-600 hover:underline ml-2">Eliminar</button>
        </td>
      `;
      tabla.appendChild(tr);
    });
  } catch (error) {
    console.error(error);
  }
}

function datosProducto(e) {
  e.preventDefault();
  const nombre = document.getElementById('nombre2').value;
  const precio = document.getElementById('precio').value;
  const stock = document.getElementById('stock').value;

  let agregarProducto = {
    nombre,
    precio: parseFloat(precio),
    stock: parseInt(stock)     
  };
  
  crearProducto(agregarProducto);
  e.target.reset();
  document.getElementById('modal-producto').classList.add("hidden"); 
}

async function crearProducto(producto) {
  try {
    const response = await fetch(API_URL_PRODUCTOS, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(producto)
    });

    if (response.ok) {
      console.log("producto agregado exitosamente!");
      listarProducto();
      cargarDashboard(); // Actualizar dashboard
    } else {
      console.error("Error al crear producto:", response.status, await response.text());
    }
  } catch (error) {
    console.error("Error de red al intentar crear producto:", error);
  }
}

function mostrarModalEditar1(producto) {
  currentEditId1 = producto.id;
  modalEdit1.classList.remove("hidden");

  document.getElementById('nombre3').value = producto.nombre;
  document.getElementById('precio2').value = producto.precio;
  document.getElementById('stock2').value = producto.stock;
}

async function actualizarProducto(e) {
  e.preventDefault();

  if (!currentEditId1) return;

  const productoActualizado = {
    nombre: document.getElementById('nombre3').value, 
    precio: parseFloat(document.getElementById('precio2').value),
    stock: parseInt(document.getElementById('stock2').value),
  };

  try {
    const response = await fetch(`${API_URL_PRODUCTOS}${currentEditId1}/`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(productoActualizado)
    });

    if (response.ok) {
      console.log("Producto actualizado exitosamente!");
      listarProducto();
      cargarDashboard(); // Actualizar dashboard
      e.target.reset();
      modalEdit1.classList.add("hidden");
    } else {
      console.error("Error al actualizar producto:", response.status, await response.text());
    }
  } catch (error) {
    console.error("Error de red al intentar actualizar producto:", error);
  }
}

async function eliminarProducto(id) {
  if (!confirm(`¿Estás seguro de que quieres eliminar el producto con ID ${id}?`)) {
    return;
  }

  try {
    const response = await fetch(`${API_URL_PRODUCTOS}${id}/`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
    });

    if (response.ok) {
      console.log("producto eliminado exitosamente!");
      listarProducto();
      cargarDashboard(); // Actualizar dashboard
    } else {
      console.error("Error al eliminar producto:", response.status, await response.text());
    }
  } catch (error) {
    console.error("Error de red al intentar eliminar producto:", error);
  }
}

// ==================== FUNCIONES DE CLIENTES ====================

async function listarClientes() {
  try {
    const res = await fetch(API_URL_CLIENTES);
    if (!res.ok) throw new Error("Error al cargar clientes");

    const data = await res.json();
    let tabla = document.getElementById("tablaClientes");
    tabla.innerHTML = "";

    data.forEach(c => {
      let tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="p-3">${c.id}</td>
        <td class="p-3">${c.nombre}</td>
        <td class="p-3">${c.direccion}</td>
        <td class="p-3">${c.telefono}</td>
        <td class="p-3">${c.email}</td>
        <td class="p-3">
          <button onclick='mostrarModalEditar(${JSON.stringify(c)})' class="text-blue-600 hover:underline">Editar</button>
          <button onclick="eliminarCliente(${c.id})" class="text-red-600 hover:underline ml-2">Eliminar</button>
        </td>
      `;
      tabla.appendChild(tr);
    });
  } catch (error) {
    console.error(error);
  }
}

function datosCliente(e) {
  e.preventDefault();
  const nombre = document.getElementById('nombre').value;
  const direccion = document.getElementById('direccion').value;
  const telefono = document.getElementById('telefono').value;
  const email = document.getElementById('email').value;

  let agregarCliente = {
    nombre,
    direccion,
    telefono,
    email
  };
  
  crearCliente(agregarCliente);
  e.target.reset();
  document.getElementById('modal-cliente').classList.add("hidden");
}

async function crearCliente(cliente) {
  try {
    const response = await fetch(API_URL_CLIENTES, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cliente)
    });

    if (response.ok) {
      console.log("Cliente agregado exitosamente!");
      listarClientes();
      cargarDashboard(); // Actualizar dashboard
    } else {
      console.error("Error al crear cliente:", response.status, await response.text());
    }
  } catch (error) {
    console.error("Error de red al intentar crear cliente:", error);
  }
}

function mostrarModalEditar(cliente) {
  currentEditId = cliente.id;
  modalEdit.classList.remove("hidden");

  document.getElementById('nombre1').value = cliente.nombre;
  document.getElementById('direccion1').value = cliente.direccion;
  document.getElementById('telefono1').value = cliente.telefono;
  document.getElementById('email1').value = cliente.email;
}

async function actualizarCliente(e) {
  e.preventDefault();

  if (!currentEditId) return;

  const clienteActualizado = {
    nombre: document.getElementById('nombre1').value,
    direccion: document.getElementById('direccion1').value,
    telefono: document.getElementById('telefono1').value,
    email: document.getElementById('email1').value
  };

  try {
    const response = await fetch(`${API_URL_CLIENTES}${currentEditId}/`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(clienteActualizado)
    });

    if (response.ok) {
      console.log("Cliente actualizado exitosamente!");
      listarClientes();
      e.target.reset();
      modalEdit.classList.add("hidden");
    } else {
      console.error("Error al actualizar cliente:", response.status, await response.text());
    }
  } catch (error) {
    console.error("Error de red al intentar actualizar cliente:", error);
  }
}

async function eliminarCliente(id) {
  if (!confirm(`¿Estás seguro de que quieres eliminar el cliente con ID ${id}?`)) {
    return;
  }

  try {
    const response = await fetch(`${API_URL_CLIENTES}${id}/`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
    });

    if (response.ok) {
      console.log("Cliente eliminado exitosamente!");
      listarClientes();
      cargarDashboard(); // Actualizar dashboard
    } else {
      console.error("Error al eliminar cliente:", response.status, await response.text());
    }
  } catch (error) {
    console.error("Error de red al intentar eliminar cliente:", error);
  }
}

// ==================== FUNCIONES DE VENTAS ====================

async function listarVentas() {
  try {
    const res = await fetch(API_URL_VENTAS);
    if (!res.ok) throw new Error("Error al cargar ventas");

    const data = await res.json();
    let tabla = document.getElementById("tablaVentas");
    tabla.innerHTML = "";

    data.forEach(v => {
      let tr = document.createElement("tr");
      // Intenta mostrar el nombre del cliente si está anidado, sino el ID
      const clienteDisplay = v.cliente_id || (v.cliente && v.cliente.nombre) || 'N/A';
      const montoTotal = parseFloat(v.monto || 0).toFixed(2);
      
      tr.innerHTML = `
        <td class="p-3">${v.id}</td>
        <td class="p-3">${clienteDisplay}</td>
        <td class="p-3">${v.fecha || 'N/A'}</td>
          <button onclick='mostrarModalEditarVenta(${JSON.stringify(v)})' class="text-blue-600 hover:underline">Editar</button>
          <button onclick="eliminarVenta(${v.id})" class="text-red-600 hover:underline ml-2">Eliminar</button>
        </td>
      `;
      tabla.appendChild(tr);
    });
  } catch (error) {
    console.error(error);
  }
}

// NUEVA FUNCIÓN: Mostrar modal de edición de Venta
function mostrarModalEditarVenta(venta) {
  currentEditVentaId = venta.id;
  modalEditVenta.classList.remove("hidden");

  // Si la API devuelve 'cliente' anidado, usa eso. Si no, usa 'cliente_id'.
  const clienteId = venta.cliente_id || (venta.cliente && venta.cliente.id);
  
  document.getElementById('clienteIdEdit').value = clienteId || '';
  document.getElementById('montoEdit').value = parseFloat(venta.monto || 0).toFixed(2);
}

// NUEVA FUNCIÓN: Actualizar Venta
async function actualizarVenta(e) {
  e.preventDefault();

  if (!currentEditVentaId) return;

  const clienteId = document.getElementById('clienteIdEdit').value;

  // Solo se envía el cliente_id ya que el monto es calculado en el backend.
  const ventaActualizada = {
    cliente_id: parseInt(clienteId), 
  };

  if (isNaN(ventaActualizada.cliente_id) || ventaActualizada.cliente_id <= 0) {
    alert("Error: El ID del cliente debe ser un número entero positivo.");
    return;
  }

  try {
    const response = await fetch(`${API_URL_VENTAS}${currentEditVentaId}/`, {
      method: "PATCH", // Usamos PATCH para actualizar parcialmente
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(ventaActualizada)
    });

    if (response.ok) {
      console.log("Venta actualizada exitosamente!");
      listarVentas();
      modalEditVenta.classList.add("hidden");
    } else {
      const errorData = await response.json(); 
      console.error("Error al actualizar venta:", response.status, errorData);
      alert(`Error al actualizar venta: ${JSON.stringify(errorData)}`);
    }
  } catch (error) {
    console.error("Error de red al intentar actualizar venta:", error);
  }
}

function datosVenta(e) {
  e.preventDefault();
  const formData = new FormData(e.target);
  
  let agregarVenta = {
    cliente_id: parseInt(formData.get('cliente')),
    monto: parseFloat(formData.get('monto')) 
  };
  
  if (isNaN(agregarVenta.cliente_id) || agregarVenta.cliente_id <= 0) {
    alert("Error: El ID del cliente debe ser un número entero positivo.");
    return;
  }
  
  crearVenta(agregarVenta);
  e.target.reset();
  document.getElementById('modal-venta').classList.add("hidden");
}

async function crearVenta(venta) {
  try {
    const response = await fetch(API_URL_VENTAS, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(venta)
    });

    if (response.ok) {
      console.log("Venta registrada exitosamente!");
      listarVentas();
      cargarDashboard(); // Actualizar dashboard
    } else {
      const errorData = await response.json(); 
      console.error("Error al crear venta:", response.status, errorData);
      alert(`Error al crear venta: ${JSON.stringify(errorData)}`);
    }
  } catch (error) {
    console.error("Error de red al intentar crear venta:", error);
  }
}

async function eliminarVenta(id) {
  if (!confirm(`¿Estás seguro de que quieres eliminar la venta con ID ${id}?`)) {
    return;
  }

  try {
    const response = await fetch(`${API_URL_VENTAS}${id}/`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
    });

    if (response.ok) {
      console.log("Venta eliminada exitosamente!");
      listarVentas();
      cargarDashboard(); // Actualizar dashboard
    } else {
      console.error("Error al eliminar venta:", response.status, await response.text());
    }
  } catch (error) {
    console.error("Error de red al intentar eliminar venta:", error);
  }
}

// ==================== FUNCIONES DE DETALLE VENTAS ====================

async function listarDetalleVentas() {
  try {
    const res = await fetch(API_URL_DETALLES);
    if (!res.ok) throw new Error("Error al cargar detalles de ventas");

    const data = await res.json();
    let tabla = document.getElementById("tablaDetalleVentas");
    tabla.innerHTML = "";

    data.forEach(d => {
      let tr = document.createElement("tr");
      // Intenta mostrar el nombre del producto si está anidado, sino el ID
      const productoDisplay = d.producto_id || (d.producto && d.producto.nombre) || 'N/A';
      
      tr.innerHTML = `
        <td class="p-3">${d.id}</td>
        <td class="p-3">Venta #${d.venta_id || d.venta}</td>
        <td class="p-3">${productoDisplay}</td>
        <td class="p-3">${d.cantidad}</td>
        <td class="p-3">$${parseFloat(d.subtotal || 0).toFixed(2)}</td>
        <td class="p-3">
          <button onclick='mostrarModalEditarDetalle(${JSON.stringify(d)})' class="text-blue-600 hover:underline">Editar</button>
          <button onclick="eliminarDetalleVenta(${d.id})" class="text-red-600 hover:underline ml-2">Eliminar</button>
        </td>
      `;
      tabla.appendChild(tr);
    });
  } catch (error) {
    console.error(error);
  }
}

// NUEVA FUNCIÓN: Mostrar modal de edición de Detalle Venta
function mostrarModalEditarDetalle(detalle) {
  currentEditDetalleId = detalle.id;
  modalEditDetalle.classList.remove("hidden");

  const ventaId = detalle.venta_id || detalle.venta;
  const productoId = detalle.producto_id || (detalle.producto && detalle.producto.id);

  document.getElementById('ventaIdEdit').value = ventaId || '';
  document.getElementById('productoIdEdit').value = productoId || '';
  document.getElementById('cantidadEdit').value = detalle.cantidad || '';
}

// NUEVA FUNCIÓN: Actualizar Detalle Venta
async function actualizarDetalleVenta(e) {
  e.preventDefault();

  if (!currentEditDetalleId) return;

  const productoId = parseInt(document.getElementById('productoIdEdit').value);
  const cantidad = parseInt(document.getElementById('cantidadEdit').value);

  const detalleActualizado = {
    producto_id: productoId, 
    cantidad: cantidad
  };

  if (productoId <= 0 || cantidad <= 0) {
      alert("Error: Por favor, ingrese un ID de Producto y una Cantidad válidos (enteros positivos).");
      return;
  }
  
  try {
    const response = await fetch(`${API_URL_DETALLES}${currentEditDetalleId}/`, {
      method: "PATCH", 
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(detalleActualizado)
    });

    if (response.ok) {
  console.log("Detalle actualizado exitosamente!");
  listarDetalleVentas();
  listarVentas(); // ESTO REFRESCARÁ LA TABLA Y EL MONTO TOTAL
  cargarDashboard(); // Esto actualiza el Ingreso Total global
  modalEditDetalle.classList.add("hidden");
} else {
      const errorData = await response.json(); 
      console.error("Error al actualizar detalle:", response.status, errorData);
      alert(`Error al actualizar detalle: ${JSON.stringify(errorData)}`);
    }
  } catch (error) {
    console.error("Error de red al intentar actualizar detalle:", error);
  }
}

function datosDetalleVenta(e) {
  e.preventDefault();
  const formData = new FormData(e.target);
  
  const ventaId = parseInt(formData.get('venta') || '0');
  const productoId = parseInt(formData.get('producto') || '0');
  const cantidad = parseInt(formData.get('cantidad') || '0');

  if (ventaId <= 0 || productoId <= 0 || cantidad <= 0) {
      alert("Error: Por favor, ingrese valores enteros positivos válidos.");
      return; 
  }
  
  let agregarDetalle = {
    venta: ventaId, 
    producto_id: productoId, 
    cantidad: cantidad
  };
  
  crearDetalleVenta(agregarDetalle);
  e.target.reset();
  document.getElementById('modal-detalle').classList.add("hidden");
}

async function crearDetalleVenta(detalle) {
  try {
    const response = await fetch(API_URL_DETALLES, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(detalle)
    });

    if (response.ok) {
      console.log("Detalle de venta agregado exitosamente!");
      listarDetalleVentas();
      listarVentas(); // Re-lista ventas para actualizar el total
      cargarDashboard(); // Actualizar dashboard
    } else {
      const errorData = await response.json(); 
      console.error("Error al crear detalle:", response.status, errorData);
      alert(`Error al crear detalle: ${JSON.stringify(errorData)}`);
    }
  } catch (error) {
    console.error("Error de red al intentar crear detalle:", error);
  }
}

async function eliminarDetalleVenta(id) {
  if (!confirm(`¿Estás seguro de que quieres eliminar el detalle con ID ${id}?`)) {
    return;
  }

  try {
    const response = await fetch(`${API_URL_DETALLES}${id}/`, {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
    });

    if (response.ok) {
      console.log("Detalle eliminado exitosamente!");
      listarDetalleVentas();
      listarVentas(); // Actualizar el total de la venta principal
      cargarDashboard(); // Actualizar dashboard
    } else {
      console.error("Error al eliminar detalle:", response.status, await response.text());
    }
  } catch (error) {
    console.error("Error de red al intentar eliminar detalle:", error);
  }
}

// ==================== FUNCIÓN CERRAR SESIÓN ====================

function cerrarSesion() {
  window.location.replace('/login/');
}

// ==================== EVENTOS ====================

document.addEventListener("DOMContentLoaded", () => {
  // Inicializar listados y el dashboard
  cargarDashboard();
  listarProducto();
  listarClientes();
  listarVentas();
  listarDetalleVentas();

  // Eventos de formularios de clientes
  if (formCliente) {
    formCliente.addEventListener('submit', datosCliente);
  }
  if (formClienteEdit) {
    formClienteEdit.addEventListener('submit', actualizarCliente);
  }

  // Eventos de formularios de productos
  if (formProducto) {
    formProducto.addEventListener('submit', datosProducto);
  }
  if (formProductoEdit) {
    formProductoEdit.addEventListener('submit', actualizarProducto);
  }

  // Eventos de formularios de ventas
  if (formVenta) {
    formVenta.addEventListener('submit', datosVenta);
  }
  if (formVentaEdit) {
    formVentaEdit.addEventListener('submit', actualizarVenta); // Evento de edición
  }

  // Eventos de formularios de detalle ventas
  if (formDetalleVenta) {
    formDetalleVenta.addEventListener('submit', datosDetalleVenta);
  }
  if (formDetalleVentaEdit) {
    formDetalleVentaEdit.addEventListener('submit', actualizarDetalleVenta); // Evento de edición
  }
});

// Evento cerrar sesión
cerrar.addEventListener("click", cerrarSesion);