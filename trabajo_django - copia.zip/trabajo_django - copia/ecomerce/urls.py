from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .api import ClienteViewSet, ProductoViewSet, VentaViewSet, DetalleVentaViewSet
from .views import dashboard, login

router = DefaultRouter()
router.register(r'clientes', ClienteViewSet, basename='clientes')
router.register(r'productos', ProductoViewSet, basename='productos')
router.register(r'ventas', VentaViewSet, basename='ventas')
router.register(r'detalles', DetalleVentaViewSet, basename='detalles')

urlpatterns = [
    path('api/', include(router.urls)),
    path("dashboard/", dashboard, name="dashboard"),
    path("login/", login, name="login")

]
