from rest_framework import serializers
from .models import Cliente, Producto, Venta, DetalleVenta


# Serializer para Cliente
class ClienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cliente
        fields = '__all__'


# Serializer para Producto
class ProductoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Producto
        fields = '__all__'


# Serializer para DetalleVenta
# Serializer para DetalleVenta
# serializers.py

# ... (otros serializers y imports)

# Serializer para DetalleVenta
class DetalleVentaSerializer(serializers.ModelSerializer):
    producto = ProductoSerializer(read_only=True)  # muestra los datos del producto
    producto_id = serializers.PrimaryKeyRelatedField(
        queryset=Producto.objects.all(), source='producto', write_only=True
    )
    # Ya corregimos la venta: acepta un ID de clave primaria
    venta = serializers.PrimaryKeyRelatedField(
        queryset=Venta.objects.all()
    )

    class Meta:
        model = DetalleVenta
        fields = ['id', 'venta', 'producto', 'producto_id', 'cantidad', 'precio_unitario', 'subtotal']
        # Hacemos estos campos de solo lectura para evitar que el cliente los envíe
        read_only_fields = ('precio_unitario', 'subtotal',)

    # MÉTODO SOBREESCRITO: Aquí se realiza el cálculo antes de guardar
    def create(self, validated_data):
        # 1. Obtener la instancia del Producto usando el producto_id (o 'producto' si lo manejas con source)
        producto = validated_data.get('producto')
        
        # 2. Obtener la cantidad
        cantidad = validated_data.get('cantidad')

        # 3. Realizar los cálculos
        precio_unitario = producto.precio
        subtotal = precio_unitario * cantidad
        
        # 4. Asignar los valores calculados a los datos validados
        validated_data['precio_unitario'] = precio_unitario
        validated_data['subtotal'] = subtotal

        # 5. Crear y devolver la instancia del DetalleVenta
        return DetalleVenta.objects.create(**validated_data)


# Serializer para Venta
class VentaSerializer(serializers.ModelSerializer):
    # LECTURA: Permite que el objeto 'cliente' completo se envíe en la respuesta GET
    cliente = ClienteSerializer(read_only=True)  
    
    # ESCRITURA: Permite recibir el ID entero como 'cliente_id' al crear/modificar
    cliente_id = serializers.PrimaryKeyRelatedField(
        queryset=Cliente.objects.all(), source='cliente', write_only=True
    )
    detalles = DetalleVentaSerializer(many=True, read_only=True)

    class Meta:
        model = Venta
        fields = ['id', 'cliente', 'cliente_id', 'fecha', 'total', 'detalles']
