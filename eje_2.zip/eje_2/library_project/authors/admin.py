from django.contrib import admin
from .models import Author

# Registra tus modelos aquí.
admin.site.register(Author)

# Register your models here.
